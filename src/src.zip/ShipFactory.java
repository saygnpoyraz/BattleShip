public abstract class ShipFactory {


    public abstract Ship produceShip();
}
