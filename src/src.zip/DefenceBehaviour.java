public interface DefenceBehaviour {
    void defence(Ship ship);
}
