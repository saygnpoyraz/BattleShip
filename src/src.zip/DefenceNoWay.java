public class DefenceNoWay implements DefenceBehaviour{
    @Override
    public void defence(Ship ship) {
        System.out.println("This Ship Cannot Defence");
    }
}
