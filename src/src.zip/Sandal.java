public class Sandal extends Ship {


}
