public interface Observer {
    void update(Ship ship);
}
