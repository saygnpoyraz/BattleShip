public interface AttackBehaviour {
    void attack(Position position);
}
