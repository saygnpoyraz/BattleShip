public class BombShip extends Ship {

}
