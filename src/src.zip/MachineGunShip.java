public class MachineGunShip extends Ship {


}
